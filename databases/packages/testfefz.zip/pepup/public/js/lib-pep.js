function _(id){
	if (window === this){
		return new _(id);
	}

	if (id){
		this.e = document.getElementById(id);
		return this;
	}
}

_.prototype = {
	accept: function(){
		alert('Accept');
	},

	decline: function(){
		alert('Decline');
	}
};